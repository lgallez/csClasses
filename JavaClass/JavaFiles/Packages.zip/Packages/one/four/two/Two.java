package one.four.two;

public class Two
{
	public void two() { System.out.println("Two");}
}