package one.four.two.five;

public class Five
{
	public void five() { System.out.println("Five");}
}