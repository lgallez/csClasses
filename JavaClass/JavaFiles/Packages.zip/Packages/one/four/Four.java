package one.four;

public class Four
{
	public void four() { System.out.println("Four");}
}