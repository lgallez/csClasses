package one;

public class One
{
	public void one() { System.out.println("One");}
}