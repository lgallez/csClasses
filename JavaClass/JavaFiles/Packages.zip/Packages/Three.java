class Three
{
	void three() { System.out.println("Three");}
}